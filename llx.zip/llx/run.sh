#!/bin/bash

./Compile.sh
./run.o $@
