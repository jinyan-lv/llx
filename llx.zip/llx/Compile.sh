#!/bin/bash

gcc run.c -o run.o
